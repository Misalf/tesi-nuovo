NOTA : La struttura cartelle (e i nomi delle stesse) contenente le impronte digitali NON DEVE ESSERE MODIFICATA, al fine di garantire che il dataset generato con questo programma presenti le impronte ordinate (sulle righe) in maniera analoga al dataset consegnato per il contest.

-------------------------

Regole di programmazione :


Utility : 

 - Unico parametro in ingresso, sempre e solo "img" 
 - Unico parametro in uscita, di nome diverso da quelli ritornarti da una qualsiasi altra utility function

Feature : 

 - Unico parametro in ingresso, sempre e solo "in_var".
    -"in_var" � una struttra composta sempre (almeno) dall' elemento puntatore all'immagine "img" (in_var.img)
    -contiene i risultati di tutte le utility function caricate (indirizzate con il nome del parametro di uscita, ex. in_var.sgcg)
 - Unico parametro in uscita, di nome diverso da qualsiasi altro ritornato dalle altre feature

-------------------------

Regole di buona composizione : 

- usare sempre nomi (sia delle feature che delle utility) altamente mnemonici, eventualmente composti anche da pi� parole
    - il corrispettivo output pu� essere banalmente formato dall'acronimo della funzione 
      ex. symmetric_gray_circularn_graycomatrix -> sgcg

