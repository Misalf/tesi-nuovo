1. Contenuto package: 4 files


        -- TrainingSet.arff:
                Campioni del dataset per l'addestramento e la valutazione del sistema di classificazione delle cellule
        
        -- MatriceDeiCosti.txt:
                Matrice dei costi su cui ottimizzare il sistema di classificazione delle cellule

        -- feature.pdf
                Elenco completo con descrizione dettagliata delle feature contenute nel file TrainingSet.arff
                Nota : gli ultimi due  attributi del dataset rappresentano l'id dell'immagine da cui è stata estratta 
                la cellula e la classe di appartenenza. 
                In totale, sono presenti 1265 feature più l'id dell'immagine e la classe.

        -- README.txt:
                Questo documento

2. Numero di Istanze:  721 
        
   	Classe		#Cellule
	centromere	208
	coarse_speckled	109
	cytoplasmatic	 58
	fine_speckled	 94
	homogeneous	150
	nucleolar	102
