﻿1. Contenuto package: 4 files


        -- TrainingSet.arff:
                Campioni del dataset per l'addestramento e la valutazione del sistema di identificazione della vitalità di impronte digitali (liveness detection)
        
        -- MatriceDeiCosti.txt:
                Matrice dei costi su cui ottimizzare il sistema di liveness detection


        -- Elenco feature - AI Contest 2013.pdf
                Elenco completo con descrizione dettagliata delle feature contenute nel file TrainingSet.arff
                Nota : Il primo attributo del dataset è l'id univoco del soggetto. L'ultimo attributo è relativo alla classe di appartenenza {0,1}. In totale, sono presenti 363 attributi più Subject_id e la classe Live.


        -- README.txt:
                Questo documento




2. Numero di Istanze:  2000 
        
   Classe     Label    #Impronte
    live        1          1000
    fake        0          1000